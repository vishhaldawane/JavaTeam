package jungle.domestic;

import org.w3c.dom.ls.LSOutput;

public class Hen {
    public void eat() {
        System.out.println("eating raw rice...");
    }
}
