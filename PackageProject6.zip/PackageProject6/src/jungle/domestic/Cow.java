package jungle.domestic;

public class Cow {
    public void gazing() {
        System.out.println("Cow is gazing....in the grass...");
    }
}
