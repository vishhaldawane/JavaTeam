package jungle.reptiles;

import jungle.wild.Tiger;

public class WhiteTiger extends Tiger {
    public void roar() {

        System.out.println("a "+a);
        System.out.println("b "+b);
        System.out.println("c "+c);
        System.out.println("d "+d); //child, but not in same package

    }
}
