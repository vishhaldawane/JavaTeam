package jungle.reptiles;

public class Crocodile {
    public void crawl() {
        System.out.println("crocodile is crawling...");
    }
}
