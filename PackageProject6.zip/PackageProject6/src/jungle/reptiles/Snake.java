package jungle.reptiles;

public class Snake {
    public void crawl() {
        System.out.println("snake is crawling...");
    }
}
