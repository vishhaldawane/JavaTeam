package jungle.birds;

public class Sparrow {
    public void fly() {
        System.out.println("sparrow is flying...");
    }
}
