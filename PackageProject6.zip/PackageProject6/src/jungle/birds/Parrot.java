package jungle.birds;

public class Parrot {
    public void fly() {
        System.out.println("Parrot is flying...");
    }
}
