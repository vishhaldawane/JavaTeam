package jungle.wild; //<-- observe this line now
                    // it means that Tiger belongs to this folder structure

 public class Tiger { //is there any constructor inside this Tiger?????YES
                //there is a default constructor available in every class
                // and that is by default public
     //THERE ARE FOUR ACCESS SPECIFIERS
     //private protected public and ........ (the default is not a keyword, it is just an awareness)

     private   int a; // private means not accessible anywhere outside of this class

     protected int b; // 1. means available to this class, to the child,

                        // 2. it is available to a non-child in the same package,
                         //BUT not outside of this package

     public    int c; //available to this class, to the child, and anywhere outside
               int d; //available to this class and only in this package, to the non-child too

     public void roar() {
        System.out.println("Tiger is roaring.....");
    }
    public Tiger() {}

}
