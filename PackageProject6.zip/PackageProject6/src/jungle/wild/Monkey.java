package jungle.wild;

public class Monkey { //non-child of Tiger
    void jumping() {


        Tiger t = new Tiger(); //do u need import line????
        t.a=10; //private - come what may, it is never accessible
        t.b=20; //protected
        t.c=30; //public
        t.d=40; //default - non-child, same package
    }
}
