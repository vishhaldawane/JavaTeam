package jungle.wild;

public class Lion {
    public void roar() {
        System.out.println("Lion is roaring...");
    }
    public Lion() {
        System.out.println("Lion constructed...");
    }
}
