package jungle.wild;

import jungle.reptiles.Crocodile;
import jungle.wild.Lion;
import jungle.wild.Tiger; // observe this line now
            // it means you want to avail the Tiger from jungle.wild package
            // so that Tiger's object can be created here
public class PackageTest {
    public static void main(String[] args) {
        Tiger tigerObj = new Tiger();
        tigerObj.roar();

        tigerObj.a=10;
        tigerObj.b=20;
        tigerObj.c=30;
        tigerObj.d=40;
















        // do you think packaging is important in IT industry for
        //banking projects in java

        /*   bank
               |
            -----------------------------------------
             |              |           |
            accounts      loans         service
            |               |               |
         SavingsAccount  CarLoan            FundTransfer
         CurrentAccount  PersonalLoan       ChequeBookService
         ....
        */
    }
}
