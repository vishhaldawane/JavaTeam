package my.relative;

import my.personal.Savings;

public class Cousin {
    void enquiring() {

        Savings savings = new Savings();
        System.out.println("how much u have in your fds : "+savings.fixedDeposits);
        System.out.println("leaning in your t shirt to see how much gold u are wearing : "+savings.gold);
        System.out.println("how many cars u have, i saw your parking photos : "+savings.numberOfCars);
        System.out.println("show me your wallet to see some cash !!! "+savings.moneyInWallet);
    }
}
