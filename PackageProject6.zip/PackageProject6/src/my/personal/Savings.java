package my.personal;

public class Savings {
    private int fixedDeposits=5000;
    protected int gold=20; //gms..wear it and few can see
    public int numberOfCars=3; //known to all
    int moneyInWallet=30; //you know whats in your wallet

}
