//when no package name is given
// that means it is belong to the default package
// and that is src folder

public class AnyClass {
}
